import { $ } from '@wdio/globals'


class OrderPage {
    productMenu(menu) {
        return $("(//a[contains(.,'" + menu + "')])[1]")
    }

    get productImage() {
        return $("(//div[@class='item-box'])[1]");
    }

    get addToCartButton() {
        return $("(//button[contains(.,'Add to cart')])[1]")
    }

    get ramDropdown() {
        return $("//select[@id='product_attribute_2']")
    }

    ram(size) {
        return $("//option[text()='" + size + "']")
    }

    get hdd() {
        return $("//label[@for='product_attribute_3_6']")
    }

    get quantityInputField() {
        return $("(//input[@class='qty-input'])[1]")
    }

    get recipientsName() {
        return $("//input[@id='giftcard_43_RecipientName']")
    }

    get recipientEmail() {
        return $("//input[@id='giftcard_43_RecipientEmail']")
    }

    get senderName() {
        return $("//input[@id='giftcard_43_SenderName']")
    }

    get senderEmail() {
        return $("//input[@id='giftcard_43_SenderEmail']")
    }

    get addToCartCrossIcon() {
        return $("//span[@class='close']");
    }

    get shoppingCartMenu() {
        return $("//span[contains(.,'Shopping cart')]")
    }

    get termsAndConditonCheckbox() {
        return $("//input[@id='termsofservice']")
    }

    get checkoutButton() {
        return $("//button[contains(.,'Checkout')]")
    }

    get checkoutAsGuestButton() {
        return $("//button[contains(.,'Checkout as Guest')]")
    }

    get baFirstName() {
        return $("//input[@id='BillingNewAddress_FirstName']")
    }

    get baLastName() {
        return $("//input[@id='BillingNewAddress_LastName']")
    }

    get baEmail() {
        return $("//input[@id='BillingNewAddress_Email']")
    }

    get baCompany() {
        return $("//input[@id='BillingNewAddress_Company']")
    }

    get baCountryDropdown() {
        return $("//select[@id='BillingNewAddress_CountryId']")
    }

    baCountry(name) {
        return $("//option[contains(.,'" + name + "')]")
    }

    async selectNewAddress() {
        const locator = "//select[@id='billing-address-select']";
        const count = (await $$(locator)).length;
        if (count > 0) {
            (await $(locator)).click();
            (await $("//option[contains(.,'New Address')]")).click();
            (await $("input[id='ShipToSameAddress']")).click();
        }
    }

    get baCityInputField() {
        return $("//input[@id='BillingNewAddress_City']")
    }

    get baAddress() {
        return $("//input[@id='BillingNewAddress_Address1']")
    }

    get baZipCode() {
        return $("//input[@id='BillingNewAddress_ZipPostalCode']")
    }

    get baPhoneNumber() {
        return $("//input[@id='BillingNewAddress_PhoneNumber']")
    }

    get baContinueButton() {
        return $("//button[text()='Continue']")
    }

    get creditCardselection() {
        return $("//label[contains(.,'Credit Card')]")
    }

    get paymentMethodContinueButton() {
        return $("//button[contains(@onclick,'PaymentMethod.save()')]")
    }

    get shippingMethodNextToAir() {
        return $("//label[contains(.,'Next Day Air')]")
    }

    get shippingMethodContinueButton() {
        return $("//button[contains(@onclick,'ShippingMethod.save()')]")
    }

    get creditCard() {
        return $("//input[@id='paymentmethod_1']")
    }

    get cardTypeDropdown() {
        return $("//select[@id='CreditCardType']")
    }

    get visaCardType() {
        return $("//option[@value='visa']")
    }

    get cardHolderNameField() {
        return $("//input[@id='CardholderName']")
    }

    get cardNumberField() {
        return $("//input[@id='CardNumber']")
    }

    get cardExpiryMonthDropdown() {
        return $("//select[@id='ExpireMonth']")
    }

    cardExpiryMonth(month) {
        return $("(//option[@value='" + month + "'])[2]")
    }

    get cardExpiryYearDropdown() {
        return $("//select[@id='ExpireYear']")
    }

    cardExpiryYear(year) {
        return $("//option[@value='" + year + "']")
    }

    get cardCodeInputField() {
        return $("//input[@id='CardCode']")
    }

    get paymentInfoContinueButton() {
        return $("//button[contains(@onclick,'PaymentInfo.save()')]")
    }

    get orderConfirmContinueButton() {
        return $("//button[contains(@onclick,'ConfirmOrder.save()')]")
    }

    get orderSuccessMsg() {
        return $("(//div[@class='title'])[1]")
    }
}

export default new OrderPage();
