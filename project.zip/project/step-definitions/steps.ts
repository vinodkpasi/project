import { Given, When, Then } from '@wdio/cucumber-framework';
import { expect, $, browser } from '@wdio/globals'
import OrderPage from '../page-objects/order.page.js';

Given('I am on the home page', async () => {
    await browser.url('/');
})

When('I click on the computers menu', async () => {
    await OrderPage.productMenu('Computers').click();
})

When('I select the Desktops from submenu', async () => {
    await OrderPage.productImage.click();
})

When('I click on the add to cart button', async () => {
    await OrderPage.addToCartButton.click();
})

When(/^I select (.*) as ram size$/, async (ramSize) => {
    await OrderPage.ram(ramSize).click();
})

When('I select hard disk', async () => {
    await OrderPage.hdd.click();
})

When(/^I select (.*) as product quantity$/, async (quantity) => {
    await OrderPage.quantityInputField.setValue(quantity);
})

When('I click on the cross icon', async () => {
    await OrderPage.addToCartCrossIcon.click();
})

When('I click on the shopping cart menu', async () => {
    await OrderPage.shoppingCartMenu.click();
})

When('I accept terms and conditons', async () => {
    await OrderPage.termsAndConditonCheckbox.click();
})

When('I click on the checkout button', async () => {
    await OrderPage.checkoutButton.click();
})

When('I click on the checkout as guest button', async () => {
    await OrderPage.checkoutAsGuestButton.click();
    await browser.pause(2000)
    OrderPage.selectNewAddress();
    console.log('x');
})

When(/^I enter (.*) as first name$/, async (firstName) => {
    await OrderPage.baFirstName.setValue(firstName);
})

When(/^I enter (.*) as last name$/, async (lastName) => {
    await OrderPage.baLastName.setValue(lastName);
})

When(/^I enter (.*) as company name$/, async (companyName) => {
    await OrderPage.baCompany.setValue(companyName);
})

When(/^I enter (.*) as email id$/, async (email) => {
    await OrderPage.baEmail.setValue(email);
})

When(/^I enter (.*) as country name$/, async (country) => {
    await OrderPage.baCountryDropdown.click();
    await OrderPage.baCountry(country).click();
})

When(/^I enter (.*) as city name$/, async (city) => {
    await OrderPage.baCityInputField.setValue(city);
})

When(/^I enter (.*) as address details$/, async (address) => {
    await OrderPage.baAddress.setValue(address);
})

When(/^I enter (.*) as zip code$/, async (zip) => {
    await OrderPage.baZipCode.setValue(zip);
})

When(/^I enter (.*) as phone number$/, async (phone) => {
    await OrderPage.baPhoneNumber.setValue(phone);
})

When('I click on the Continue button', async () => {
    await OrderPage.baContinueButton.click();
})

When('I choose the air shipping method', async () => {
    await OrderPage.shippingMethodNextToAir.click();
    await OrderPage.shippingMethodContinueButton.click();
})

When('I choose the payment method', async () => {
    await OrderPage.creditCard.click();
    await OrderPage.paymentMethodContinueButton.click();
    await OrderPage.cardTypeDropdown.click();
    await OrderPage.visaCardType.click();
})

When(/^I enter (.*),(.*),(.*),(.*) and (.*) as card details$/, async (cardHolderName, cardNo, expiryMonth, expiryYear, cvv) => {
    await OrderPage.cardHolderNameField.setValue(cardHolderName);
    await OrderPage.cardNumberField.setValue(cardNo);
    await OrderPage.cardExpiryMonthDropdown.click();
    await OrderPage.cardExpiryMonth(expiryMonth).click();
    await OrderPage.cardExpiryYearDropdown.click();
    await OrderPage.cardExpiryYear(expiryYear).click();
    await OrderPage.cardCodeInputField.setValue(cvv)
})

When('I click on the payment info continue button', async () => {
    await OrderPage.paymentInfoContinueButton.click();
    await browser.pause(5000);
})

When('I should see order confirmation message for placed order', async () => {
    await OrderPage.orderConfirmContinueButton.isDisplayed();
    await OrderPage.orderConfirmContinueButton.click();
    await browser.pause(5000)
})


