    Cucumber Integration
    Multiple Cucumber Report
    Maximize browser on start
    Scenario Outline
    POM
    TypeScript configuration
    .vscode integration
    Attach screenshot in report
