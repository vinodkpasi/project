import { $ } from '@wdio/globals'


class OrderPage {
    productMenu(menu) {
        return $("(//a[contains(.,'" + menu + "')])[1]")
    }

    get productImage() {
        return $("(//div[@class='item-box'])[1]");
    }

    get addToCartButton() {
        return $("(//button[contains(.,'Add to cart')])[1]")
    }

    get ramDropdown() {
        return $("#product_attribute_2")
    }

    ram(size) {
        return $("//option[text()='" + size + "']")
    }

    get hdd() {
        return $("label[for='product_attribute_3_6']")
    }

    get quantityInputField() {
        return $("(//input[@class='qty-input'])[1]")
    }

    get recipientsName() {
        return $("#giftcard_43_RecipientName")
    }

    get recipientEmail() {
        return $("#giftcard_43_RecipientEmail")
    }

    get senderName() {
        return $("#giftcard_43_SenderName")
    }

    get senderEmail() {
        return $("#giftcard_43_SenderEmail")
    }

    get addToCartCrossIcon() {
        return $("span.close");
    }

    get shoppingCartMenu() {
        return $("//span[contains(.,'Shopping cart')]")
    }

    get termsAndConditonCheckbox() {
        return $("#termsofservice")
    }

    get checkoutButton() {
        return $("//button[contains(.,'Checkout')]")
    }

    get checkoutAsGuestButton() {
        return $("//button[contains(.,'Checkout as Guest')]")
    }

    get baFirstName() {
        return $("#BillingNewAddress_FirstName")
    }

    get baLastName() {
        return $("#BillingNewAddress_LastName")
    }

    get baEmail() {
        return $("#BillingNewAddress_Email")
    }

    get baCompany() {
        return $("#BillingNewAddress_Company")
    }

    get baCountryDropdown() {
        return $("#BillingNewAddress_CountryId")
    }

    baCountry(name) {
        return $("//option[contains(.,'" + name + "')]")
    }

    async selectNewAddress() {
        const locator = "#billing-address-select";
        const count = (await $$(locator)).length;
        if (count > 0) {
            (await $(locator)).click();
            (await $("//option[contains(.,'New Address')]")).click();
            (await $("#ShipToSameAddress")).click();
        }
    }

    get baCityInputField() {
        return $("#BillingNewAddress_City")
    }

    get baAddress() {
        return $("#BillingNewAddress_Address1")
    }

    get baZipCode() {
        return $("#BillingNewAddress_ZipPostalCode")
    }

    get baPhoneNumber() {
        return $("#BillingNewAddress_PhoneNumber")
    }

    get baContinueButton() {
        return $("//button[text()='Continue']")
    }

    get creditCardselection() {
        return $("//label[contains(.,'Credit Card')]")
    }

    get paymentMethodContinueButton() {
        return $("//button[contains(@onclick,'PaymentMethod.save()')]")
    }

    get shippingMethodNextToAir() {
        return $("//label[contains(.,'Next Day Air')]")
    }

    get shippingMethodContinueButton() {
        return $("//button[contains(@onclick,'ShippingMethod.save()')]")
    }

    get creditCard() {
        return $("#paymentmethod_1")
    }

    get cardTypeDropdown() {
        return $("#CreditCardType")
    }

    get visaCardType() {
        return $("option[value='visa']")
    }

    get cardHolderNameField() {
        return $("#CardholderName")
    }

    get cardNumberField() {
        return $("#CardNumber")
    }

    get cardExpiryMonthDropdown() {
        return $("#ExpireMonth")
    }

    cardExpiryMonth(month) {
        return $("(//option[@value='" + month + "'])[2]")
    }

    get cardExpiryYearDropdown() {
        return $("#ExpireYear")
    }

    cardExpiryYear(year) {
        return $("option[value='" + year + "']")
    }

    get cardCodeInputField() {
        return $("#CardCode")
    }

    get paymentInfoContinueButton() {
        return $("//button[contains(@onclick,'PaymentInfo.save()')]")
    }

    get orderConfirmContinueButton() {
        return $("//button[contains(@onclick,'ConfirmOrder.save()')]")
    }

    get orderSuccessMsg() {
        return $("(//div[@class='title'])[1]")
    }

    async verifyConfirmationMessage() {
        await this.orderConfirmContinueButton.isDisplayed();
        await this.orderConfirmContinueButton.click();
        await browser.pause(5000)
    }

    async enterCreditCardDetails(cardHolderName, cardNo, expiryMonth, expiryYear, cvv) {
        await this.cardHolderNameField.setValue(cardHolderName);
        await this.cardNumberField.setValue(cardNo);
        await this.cardExpiryMonthDropdown.click();
        await this.cardExpiryMonth(expiryMonth).click();
        await this.cardExpiryYearDropdown.click();
        await this.cardExpiryYear(expiryYear).click();
        await this.cardCodeInputField.setValue(cvv);
    }

    async selectVisaCreditCard() {
        await this.creditCard.click();
        await this.paymentMethodContinueButton.click();
        await this.cardTypeDropdown.click();
        await this.visaCardType.click();
    }

    async selectAirShipping() {
        await this.shippingMethodNextToAir.click();
        await this.shippingMethodContinueButton.click();
    }

    async selectCountry(country) {
        await this.baCountryDropdown.click();
        await this.baCountry(country).click();
    }

    async checkoutAsGuest() {
        await this.checkoutAsGuestButton.click();
        await browser.pause(2000);
        this.selectNewAddress();
    }

    async selectRamSize(ramSize) {
        await this.ram(ramSize).click();
    }

    async selectQuantity(quantity) {
        await this.quantityInputField.setValue(quantity);
    }

    async enterFirstName(firstName) {
        await this.baFirstName.setValue(firstName);
    }

    async enterLastName(lastName) {
        await this.baLastName.setValue(lastName);
    }

    async enterCompanyName(companyName) {
        await this.baCompany.setValue(companyName);
    }

    async enterEmail(email) {
        await this.baEmail.setValue(email);
    }

    async enterCity(city) {
        await this.baCityInputField.setValue(city);
    }

    async enterAddress(address) {
        await this.baAddress.setValue(address);
    }

    async enterZipCode(zip) {
        await this.baZipCode.setValue(zip);
    }

    async enterPhone(phone) {
        await this.baPhoneNumber.setValue(phone);
    }

    async getErrorMessage(msg) {
        return $("//span[@class='field-validation-error' and text()='"+msg+"']");
    }
}

export default new OrderPage();
