import { Given, When, Then } from '@wdio/cucumber-framework';
import { expect, $, browser } from '@wdio/globals'
import OrderPage from '../page-objects/order.page.js';

Given('I am on the home page', async () => {
    await browser.url('/');
})

When('I click on the computers menu', async () => {
    const computersMenu = await OrderPage.productMenu('Computers');
    await expect(computersMenu).toBeDisplayed()
    await computersMenu.click();
})

When('I select the Desktops from submenu', async () => {
    const productImage = await OrderPage.productImage
    await expect(productImage).toBeDisplayed()
    await productImage.click();
})

When('I click on the add to cart button', async () => {
    const addToCartButton = await OrderPage.addToCartButton
    await expect(addToCartButton).toBeDisplayed()
    await addToCartButton.click();
})

When(/^I select (.*) as ram size$/, async (ramSize) => {
    await OrderPage.selectRamSize(ramSize);
})

When('I select hard disk', async () => {
    const hdd = await OrderPage.hdd
    await expect(hdd).toBeDisplayed()
    await hdd.click();
})

When(/^I select (.*) as product quantity$/, async (quantity) => {
    await OrderPage.selectQuantity(quantity);
})

When('I click on the cross icon', async () => {
    const addToCartCrossIcon = await OrderPage.addToCartCrossIcon
    await expect(addToCartCrossIcon).toBeDisplayed()
    await addToCartCrossIcon.click();
})

When('I click on the shopping cart menu', async () => {
    const shoppingCartMenu = await OrderPage.shoppingCartMenu
    await expect(shoppingCartMenu).toBeDisplayed()
    await shoppingCartMenu.click();
})

When('I accept terms and conditons', async () => {
    const termsAndConditonCheckbox = await OrderPage.termsAndConditonCheckbox
    await expect(termsAndConditonCheckbox).toBeDisplayed()
    await termsAndConditonCheckbox.click();
})

When('I click on the checkout button', async () => {
    const checkoutButton = await OrderPage.checkoutButton
    await expect(checkoutButton).toBeDisplayed()
    await checkoutButton.click();
})

When('I click on the checkout as guest button', async () => {
    await OrderPage.checkoutAsGuest();
})

When(/^I enter (.*) as first name$/, async (firstName) => {
    await OrderPage.enterFirstName(firstName);
})

When(/^I enter (.*) as last name$/, async (lastName) => {
    await OrderPage.enterLastName(lastName);
})

When(/^I enter (.*) as company name$/, async (companyName) => {
    await OrderPage.enterCompanyName(companyName);
})

When(/^I enter (.*) as email id$/, async (email) => {
    await OrderPage.enterEmail(email);
})

When(/^I enter (.*) as country name$/, async (country) => {
    await OrderPage.selectCountry(country);
})

When(/^I enter (.*) as city name$/, async (city) => {
    await OrderPage.enterCity(city);
})

When(/^I enter (.*) as address details$/, async (address) => {
    await OrderPage.enterAddress(address);
})

When(/^I enter (.*) as zip code$/, async (zip) => {
    await OrderPage.enterZipCode(zip);
})

When(/^I enter (.*) as phone number$/, async (phone) => {
    await OrderPage.enterPhone(phone);
})

When(/^I should see (.*) as error message$/, async (msg) => {
    await browser.pause(5000);
    const lblError = await OrderPage.getErrorMessage(msg)
    await expect(lblError).toBeDisplayed()
})

When('I click on the Continue button', async () => {
    const baContinueButton = await OrderPage.baContinueButton
    await expect(baContinueButton).toBeDisplayed()
    await baContinueButton.click();
})

When('I choose the air shipping method', async () => {
    await OrderPage.selectAirShipping();
})

When('I choose the payment method', async () => {
    await OrderPage.selectVisaCreditCard();
})

When(/^I enter (.*),(.*),(.*),(.*) and (.*) as card details$/, async (cardHolderName, cardNo, expiryMonth, expiryYear, cvv) => {
    await OrderPage.enterCreditCardDetails(cardHolderName, cardNo, expiryMonth, expiryYear, cvv);
})

When('I click on the payment info continue button', async () => {
    await OrderPage.paymentInfoContinueButton.click();
    await browser.pause(5000);
})

When('I should see order confirmation message for placed order', async () => {
    await OrderPage.verifyConfirmationMessage()
})


